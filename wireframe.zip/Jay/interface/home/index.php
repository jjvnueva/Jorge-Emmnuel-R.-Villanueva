<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="css/home_style.css">
    </head>

    <body>
        <div class="image1"><h1>Image</div>
    </body>
</html>