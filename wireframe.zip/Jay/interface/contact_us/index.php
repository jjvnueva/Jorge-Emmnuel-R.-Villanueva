<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="css/contact_us_style.css">
    </head>

    <body>
        <div class="contact_information1"><h1>Contact Information</h1></div>
    </body>
</html>