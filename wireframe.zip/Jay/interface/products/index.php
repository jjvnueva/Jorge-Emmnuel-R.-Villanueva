<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="css/products_style.css">
    </head>

    <body>
        <div class="categories1"><h1>Product Categories</h1></div>
        <div class="details1"><h1>Product Details</h1></div>
    </body>
</html>