<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="css/about_us_style.css">
    </head>

    <body>
        <div class="history1"><h1>History About The Diner</h1></div>
        <div class="image1"><h1>Pictures</h1></div>
    </body>
</html>